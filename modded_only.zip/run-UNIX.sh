#!/bin/bash

java -Xms128M -Xmx4096M -jar server.jar -nogui
